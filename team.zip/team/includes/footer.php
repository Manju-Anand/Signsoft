<!-- Sidebar -->
<div class="sidebar sidebar-right sidebar-animate">
			<div class="sidebar-icon">
				<a href="javascript:void(0);" class="text-right float-end text-dark fs-20 mt-2"
					data-bs-toggle="sidebar-right" data-bs-target=".sidebar-right"><i class="fe fe-x"></i></a>
			</div>
			<div class="sidebar-body">
				<h4 class="mt-3 ms-3">Notifications</h4>
				<hr class="mb-2">
				<div class="panel panel-primary">
					<div class="tab-menu-heading">
						<div class="tabs-menu">
							<!-- Tabs -->
							<ul class="nav panel-tabs justify-content-center">
								<li><a href="#tab1" class="active" data-bs-toggle="tab">Friends</a></li>
								<li><a href="#tab2" data-bs-toggle="tab">Chats</a></li>
								<li><a href="#tab3" data-bs-toggle="tab">Notifications</a></li>
							</ul>
						</div>
					</div>
					<div class="panel-body tabs-menu-body">
						<div class="tab-content">
							<div class="tab-pane active" id="tab1">
								<div class="tab-pane" id="friends" tabindex="0">
									<ul class="list-unstyled list-group list-group-flush">
										<li class="px-0 py-2">
											<div class="d-flex align-items-start">
												<div class="d-flex align-items-center flex-grow-1 overflow-hidden position-relative">
													<a href="javascript:void(0);" class="stretched-link"></a>
													<div class="me-2 min-w-fit-content">
														<img src="../assets/img/users/12.jpg" alt="img" class="avatar avatar-sm rounded-circle">
													</div>
													<div class="flex-grow-1">
														<p class="mb-0 tx-medium text-truncate fs-15">Socrates Itumay</p>
														<span class="fs-11 text-muted text-truncate">(11)+390-2309</span>
													</div>
												</div>
												<a href="javascript:void(0);" class="mt-3 me-2">
													<i class="fe fe-edit fs-16"></i>
												</a>
											</div>
										</li>
										
									</ul>
								</div>
							</div>
							<div class="tab-pane" id="tab2">
								<div class="list-group list-group-flush">
									<div class="d-flex px-0 py-2">
										<div class="me-2">
											<span class="avatar avatar-sm brround cover-image"
												data-bs-image-src="../assets/img/users/2.jpg"><span
												class="avatar-status"></span></span>
										</div>
										<div class="">
											<a href="chat.html">
												<div class="tx-medium text-dark" data-bs-toggle="modal"
													data-target="#chatmodel">Airi Satou</div>
												<p class="mb-0 fs-11 text-muted"> Hey! there I' am available.... </p>
											</a>
										</div>
										<a href="javascript:void(0);" class="ms-auto fs-16 me-2"><i class="fa fa-angle-right"></i></a>
									</div>
									
								</div>
							</div>
							<div class="tab-pane" id="tab3">
								<div class="list-group list-group-flush">
									<div class="d-flex px-0 py-2 ">
										<div class="me-2">
											<span class="avatar avatar-sm brround cover-image"
												data-bs-image-src="../assets/img/users/1.jpg"></span>
										</div>
										<div class="">
											<a href="chat.html">
												<div class="tx-medium text-dark">Madeleine</div>
												<p class="mb-0 fs-11 text-muted">Hey! there I'am available...</p>
											</a>
										</div>
										<a href="javascript:void(0);" class="ms-auto fs-13 mt-1"><i class="fe fe-x"></i></a>
									</div>
									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		<!-- End Sidebar -->

		<!-- Main Footer-->
		<div class="main-footer text-center">
			<div>
				<div class="row">
					<div class="col-md-12">
						<span>Copyright © <script>document.write(new Date().getFullYear())</script> <a href="javascript:void(0);" class="text-primary">Signsoft</a>. Designed
							with <span class="fa fa-heart text-danger"></span> by <a href="https://www.signefo.com/"
								class="text-primary">Signefo</a>
							All rights reserved.</span>
					</div>
				</div>
			</div>
		</div>
		<!--End Footer-->