<?php
$connection = mysqli_connect('localhost', 'root', '', 'signsoft');
$db = mysqli_connect('localhost', 'root', '', 'signsoft');
$connect = mysqli_connect('localhost', 'root', '', 'signsoft');

?>